# Curated Sequences

The translation alignments from code. See:    

	sftp://hpcnode1.utm.utoronto.ca//scratch/research/projects/chlamydomonas/mt_locus_recombination/analysis/cds-popgen/TranslationAligner/TranslationAlignSharedGenes.ipynb) have been exported to Geneious for manual editing.

Each alignment was investigated individuall to look for gross alignment errors
In general:
 - 41 of 54 alignments were clearly done well
 - 3 of 54 were eliminated as gametolog assignment was too ambiguous and the alignments were not meaningful
 - 10 were edited to account for large indels
		-These indels were all the result of differences in the 5' or 3' ends of the sequence. In general these resulted from novel sequence in one gametolog. 
		- The solution was to offset the indel regions to create in frame indesl that meant no non-homologous sequence will be compared in subsequent steps

### The result was 51 confirmed sequences to be used for subsequent analysis

The details of this analysis are all recorded in 

	`57 documents from translationAlignment.geneious`

